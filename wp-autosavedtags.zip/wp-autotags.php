<?php
/*
Plugin Name: AutoSaved Post Tags
Plugin URI: http://cn.aliceding.com/wordpressplugins/autoposttags
Description: This plugin help people add tags to the post automatically when you do not set up tags.  The tag extraction based on TF-IDF implementation. Built-in TF-IDF interface does not work when you try to find an existing tag in WordPress. If found, these markers are added to the post automatically each time you save the post.
Version: 1.1
Author:Alice Ding
Author URI: http://cn.aliceding.com
Requires at least: 3.9
Tested up to: 4.9.3
License: GPLv2
Tags: auto tag, tags, post tag, autosave tag
*/
/*

Copyright (c) cn.aliceding.com

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

function autotags_html2text($ep){
    $search = array("'<script[^>]*?>.*?</script>'si", "'<[\/\!]*?[^<>]*?>'si", "'([\r\n])[\s]+'", "'&(quot|#34|#034|#x22);'i", "'&(amp|#38|#038|#x26);'i", "'&(lt|#60|#060|#x3c);'i", "'&(gt|#62|#062|#x3e);'i", "'&(nbsp|#160|#xa0);'i", "'&(iexcl|#161);'i", "'&(cent|#162);'i", "'&(pound|#163);'i", "'&(copy|#169);'i", "'&(reg|#174);'i", "'&(deg|#176);'i", "'&(#39|#039|#x27);'", "'&(euro|#8364);'i", "'&a(uml|UML);'", "'&o(uml|UML);'", "'&u(uml|UML);'", "'&A(uml|UML);'", "'&O(uml|UML);'", "'&U(uml|UML);'", "'&szlig;'i", );
    $replace = array("", "", "\\1", "\"", "&", "<", ">", " ", chr(161), chr(162), chr(163), chr(169), chr(174), chr(176), chr(39), chr(128), "ä", "ö", "ü", "Ä", "Ö", "Ü", "ß", );
    return preg_replace($search, $replace, $ep);
}

function autotags_sanitize( $taglist ) {
    $special_chars = array('?','、','。','“','”','《','》','！','，','：','？','.','[',']','/','\\','\=','<','>',':',';','\'','"','&','$','#','*','(',')','|','~','`','!','{','}','%','+', chr(0));
    /**
     * Filter the list of characters to remove from a taglist.
     * @param array  $special_chars Characters to remove.
     */
    $taglist = preg_replace( "#\x{00a0}#siu", ' ', $taglist );
    $taglist = str_replace( $special_chars, '', $taglist );
    $taglist = str_replace( array( '%20', '+' ), '-', $taglist );
    $taglist = preg_replace( '/[\r\n\t -]+/', '-', $taglist );
    $taglist = trim( $taglist, ',-_' );
    return $taglist;
}

function autotags_keycontents($keys,$num){
    $request = wp_remote_request('http://cws.9sep.org/extract/json',array('method'=>'POST','timeout'=>20,'body'=>array('text'=>$keys,'topk'=>$num)));
    if(wp_remote_retrieve_response_code($request) != 200){
        return 'rEr';
    }else{
        return wp_remote_retrieve_body($request);
    }
}

function autotags_kwsiconv($kws){
    return autotags_sanitize(@json_decode($kws,true)['kws']);
}

function autotags_alts($post_ID,$post_title,$post_content){
    $tags = get_tags( array('hide_empty' => false) );
    $tagx=get_option('autotags_opts');
    $number=get_option('autotags_aadnumber');
    switch ($tagx) {
        case 3:
            $d = strtolower($post_title.' '.wp_trim_words($post_content,2000,''));
            break;
        case 2:
            $d = strtolower($post_title.' '.wp_trim_words($post_content,2000,''));
            break;
        default:
            $d = strtolower($post_title);
            break;
    }
    if ($tags) {
        $i=0;
        foreach ( $tags as $tag ) {
            if ( strpos($d, strtolower($tag->name)) !== false ){
                wp_set_post_tags( $post_ID, $tag->name, true );
                $i++;
            }
            if ($i == $number) break;
        }
    }
}

function autotags_run($post_ID){
    $tags=get_option('autotags_opts');
    $number=get_option('autotags_aadnumber');
    global $wpdb;
    if(get_post($post_ID)->post_type == 'post' && !wp_is_post_revision($post_ID) && !get_the_tags($post_ID)) {
        $post_title = get_post($post_ID)->post_title;
        $post_content = get_post($post_ID)->post_content;
        switch ($tags) {
            case 3:
                $requix = strtolower($post_title.' '.wp_trim_words($post_content,2000,''));
                break;
            case 2:
                $requix = strtolower($post_title.' '.wp_trim_words($post_content,2000,''));
                break;
            default:
                $requix = strtolower($post_title);
                break;
        }
        $body = autotags_keycontents(autotags_html2text($requix),$number);
        if ($body != 'rEr') {
            $keywords = autotags_kwsiconv($body);
            wp_add_post_tags($post_ID , $keywords);
        }else{
            autotags_alts($post_ID,$post_title,$post_content);
        }
    }
}

function autotags_admin_init(){
    if(get_bloginfo('language')=='zh-CN'||get_bloginfo('language')=='zh-TW'){
        $autotags_setting='tag range';
        $autotags_number='tag numbers';
    }else{
        $autotags_setting='Matching range';
        $autotags_number='Automatic Tags number';
    }
    add_settings_field('autotags_opts',$autotags_setting,'autotags_setting','writing','default');
    add_settings_field('autotags_aadnumber',$autotags_number,'autotags_aadnumber','writing','default');

    register_setting( 'writing', 'autotags_opts' );
    register_setting( 'writing', 'autotags_aadnumber' );
}

function autotags_install($obj){
    add_option('autotags_opts',3);
    add_option('autotags_aadnumber',3);
}

function autotags_uninstall(){
    delete_option('autotags_opts');
    delete_option('autotags_aadnumber');
    remove_action('admin_init','autotags_admin_init');
}

function autotags_setting(){
    $autotags_opts = get_option('autotags_opts');
?>

<select name="autotags_opts">
    <option value="1" <?php selected('1', $autotags_opts ); ?>><?php if(get_bloginfo('language')=='zh-CN'||get_bloginfo('language')=='zh-TW'): ?>Only use post title to generate tags?<?php else: ?>Only use post title to generate tags?<?php endif; ?></option>
    <option value="2" <?php selected('2', $autotags_opts ); ?>><?php if(get_bloginfo('language')=='zh-CN'||get_bloginfo('language')=='zh-TW'): ?>Use post content to generate tags automatically<?php else: ?>Use post content to generate tags automatically<?php endif; ?></option>
    <option value="3" <?php selected('3', $autotags_opts ); ?>><?php if(get_bloginfo('language')=='zh-CN'||get_bloginfo('language')=='zh-TW'): ?>Use both post title and content to generate tags automatically<?php else: ?>Use both post title and content to generate tags automatically<?php endif; ?></option>
</select>

<?php
}

function autotags_aadnumber(){
    $autotags_aadnumber = get_option('autotags_aadnumber');
?>

<p><label><input name="autotags_aadnumber" type="radio" value="3" <?php checked('3', $autotags_aadnumber ); ?>>3 </label><label><input name="autotags_aadnumber" type="radio" value="5" <?php checked('5', $autotags_aadnumber ); ?>> 5 </label><label><input name="autotags_aadnumber" type="radio" value="9" <?php checked('9', $autotags_aadnumber ); ?>> 9 </label><label><input name="autotags_aadnumber" type="radio" value="15" <?php checked('15', $autotags_aadnumber ); ?>> 15</label></p>

<?php
}

register_activation_hook(__FILE__,'autotags_install');
register_deactivation_hook(__FILE__,'autotags_uninstall');

add_action('admin_init','autotags_admin_init');

add_action('publish_post','autotags_run');
add_action('edit_post','autotags_run');


